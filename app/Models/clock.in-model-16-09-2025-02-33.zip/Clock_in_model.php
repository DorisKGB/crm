<?php

namespace App\Models;

class Clock_in_model extends Crud_model
{
    protected $table = null;

    function __construct()
    {
        $this->table = 'clock_in';
        parent::__construct($this->table);
    }
    public function get_by_range($userId, $from, $to)
    {
        return $this->db->table('clock_in')
            ->where('user_id', $userId)
            ->where('date >=', $from)
            ->where('date <=', $to)
            ->orderBy('date')
            ->orderBy('time')
            ->get()
            ->getResult('object'); // Muy importante
    }

}