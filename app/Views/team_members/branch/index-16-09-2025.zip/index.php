<div class="tab-content">

<?php
    $reload_url = get_uri("team_members/branch/" . $user_id);
    $save_url = get_uri("team_members/save_branch/" . $user_id);
    $show_submit = true;

    /*if (isset($user_type)) {
        if ($user_type === "client") {
            $reload_url = "";
            $save_url = get_uri("clients/save_contact_social_links/" . $user_id);
            if (isset($can_edit_clients) && !$can_edit_clients) {
                $show_submit = false;
            }
        } else if ($user_type === "lead") {
            $reload_url = "";
            $save_url = get_uri("leads/save_contact_social_links/" . $user_id);
        }
    }*/

    //echo form_open(get_uri("team_members/save_branch/" . $user_id), array("id" => "general-info-form", "class" => "general-form dashed-row white", "role" => "form")); 
    echo form_open($save_url, array("id" => "social-links-form", "class" => "general-form dashed-row white", "role" => "form"));
    
    ?>
    
<div class="card rounded-bottom">
    <div class="card-header">
        <h4><?php echo app_lang('branches'); ?> </h4>
        <p><?php echo  app_lang('details_admon_daily_reports') ?></p>
    </div>
    
        <div class="card-body">
            <input type="hidden" name="user_id" value="<?php echo $user_id ?>">
            <div class="form-group">
                <button type="button" id="toggleAllBtn" class="btn btn-primary btn-sm"><?php echo  app_lang('check_uncheck_all') ?></button>
            </div>
            <?php foreach($clinics as $clinic){ ?>
            <div class="form-group">
                <div class="row">
                    <label for="disable_login<?php echo $clinic['id']; ?>" class="col-md-2"><?php echo $clinic['name'] ?></label>
                    <div class="col-md-10">
                        <!--<input type="checkbox" name="clinic_list[]" value="<?php echo $clinic['id']; ?>" id="user_status"
                            class="ml15 form-check-input mt-2 " >-->

                            <?php
                            echo form_checkbox('clinic_list[]', $clinic['id'], $clinic['used']==0?false : true, "class='ml15 form-check-input mt-2'");
                            ?>
                    </div>

                 

                </div>
            </div>
            <?php } ?>
        
            <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>

        </div>
        <?php echo form_close(); ?>


        <script>
            document.getElementById('toggleAllBtn').addEventListener('click', function() {
                const checkboxes = document.querySelectorAll('.form-check-input');
                let allChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);
                checkboxes.forEach(checkbox => {
                    checkbox.checked = !allChecked;
                });
            });
        </script>
</div>
</div>
