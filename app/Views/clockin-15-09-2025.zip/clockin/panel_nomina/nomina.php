<?php
// Calcular valores predeterminados
$from = $_GET['from'] ?? date('Y-m-d', strtotime('-1 month'));
$to = $_GET['to'] ?? date('Y-m-d');
$user_id = $_GET['user_id'] ?? 0; // mantener user_id en la URL
?>

<div id="panel-personal" class="panel-section <?= $activeOption === 'nomina' ? 'active' : '' ?>">

    <h3 class="d-flex justify-content-between align-items-center">
        <span><b><i class="fas fa-search-dollar"></i> <?= app_lang('text_nav_momina'); ?></b></span>
        <?php if (isset($data_clinic)) : ?>
            <span class="clinic-badge" style="font-size: 16px;"><i
                    class="fas fa-check-circle"></i><?= esc($data_clinic->name) ?></span>
        <?php endif; ?>
    </h3>
    <p> <?= app_lang('text_nav_momina_details'); ?></p>

    <?php if (!isset($_GET['user_id'])): ?>
        <div class="row mt-4">
            <?php foreach ($users as $user): ?>
                <div class="col-md-3">
                    <div class="card targetCard">
                        <div class="card-body text-center">
                            <?php if ($user->image != ""): ?>
                                <img src="<?php echo get_avatar($user->image); ?>" class="rounded-circle" width="100"
                                    alt="Foto de <?= esc($user->first_name) ?>"
                                    style="object-fit: cover; border:10px solid #f3f3f3; cursor:pointer;">
                            <?php else: ?>
                                <img src="<?php echo base_url("public/uploads/clinics/default-clinic.png"); ?>"
                                    class="rounded-circle" width="100" alt="Foto por defecto"
                                    style="object-fit: cover; border:10px solid #f3f3f3; cursor:pointer;">
                            <?php endif; ?>
                            <p class="text-center"><?= esc($user->first_name); ?>
                                <?= esc($user->last_name); ?></p>
                            <p><span class="badge badge-success"><?= esc($user->job_title) ?></span></p>
                            <p>
                                <button class="btn-rubymed btn-rubymed-success-in ver-nomina" data-user="<?= $user->id ?>">
                                    <i class="fas fa-dollar-sign"></i> <?= app_lang('text_view_nomina'); ?>
                                </button>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <?php if (isset($nominas)): ?>
            <div>
                <div class="row">
                    <div class="col-md-5 d-flex ">
                        <div>
                            <img src="<?php echo get_avatar($data_user->image); ?>" class="rounded-circle" width="100"
                                alt="Foto de <?= esc($data_user->first_name) ?>"
                                style="object-fit: cover; border:5px solid #f3f3f3; cursor:pointer;">
                        </div>

                        <div class="ms-4">

                            <h4 class="ml-3"><b><?= esc($data_user->first_name) ?>
                                    <?= esc($data_user->last_name) ?></b>
                            </h4>
                            <p><?= esc($data_user->job_title) ?></p>
                            <p><?= esc($data_user->email) ?></p>

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="">
                            <div class="row mb-4">
                                <div class="col-md-12 mt-5">
                                    <form id="formNomina" class="d-flex align-items-center gap-3">
                                        <span><?= app_lang('text_from') ?>: </span>
                                        <input type="text" id="fromDate" name="from" class="form-control" placeholder="Desde" value="<?= $from ?>" style="max-width: 200px;">
                                        <span><?= app_lang('text_to') ?>: </span>
                                        <input type="text" id="toDate" name="to" class="form-control" placeholder="Hasta" value="<?= $to ?>" style="max-width: 200px;">
                                        <button type="submit" class="btn-rubymed btn-rubymed-success-in"><i class="fas fa-search"></i> Consultar</button>
                                    </form>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-4 mt-4 p-4" >

                                <!-- Total de Horas -->
                                <div class="text-center">
                                    <div class=" d-flex p-4"
                                        style="background-color: #d1f7e2; color: #155724; font-size: 20px; font-weight: bold;border-radius:15px;">
                                        <?= esc($nominas['total_horas']) ?>
                                    </div>
                                    <small class="mt-2 d-block "><b><?= app_lang('text_total_hour') ?></b></small>
                                </div>

                                <span style="font-size:25px;">X</span>
                                <!-- Salario por Hora -->
                                <div class="text-center">
                                    <div class=" d-flex p-4"
                                        style="background-color: #d1ecf1; color: #0c5460; font-size: 20px; font-weight: bold;border-radius:15px;">
                                        $ <?= esc($nominas['salario_hora']) ?>
                                    </div>
                                    <small class="mt-2 d-block "><b><?= app_lang('text_salary_hour') ?></b></small>
                                </div>
                                <span style="font-size:25px;">=</span>
                                <!-- Total Nómina -->
                                <div class="text-center">
                                    <div class=" d-flex p-4"
                                        style=" background-color: #fbe4d5; color: #8a4b08; font-size: 20px; font-weight: bold;border-radius:15px;">
                                        $ <?= esc(round($nominas['total'], 2)) ?>
                                    </div>
                                    <small class="mt-2 d-block "><b><?= app_lang('text_total_nomina') ?></b></small>
                                </div>

                            </div>
                        </div>

                    </div>



                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>