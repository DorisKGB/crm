<div class="modal fade" id="modalCreateService" tabindex="-1" aria-labelledby="modalCreateServiceLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalCreateServiceLabel">
                    <i class="fas fa-plus-circle"></i> Crear Nuevo Servicio Domiciliario
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="createServiceForm"  method="POST" enctype="multipart/form-data">
               <?= csrf_field() ?>
                <div class="modal-body">
                    <!-- Progreso de pasos -->
                    <div class="progress mb-4" style="height: 6px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 25%" id="progressBar"></div>
                    </div>
                    
                    <!-- Indicadores de pasos -->
                    <div class="row mb-4">
                        <div class="col text-center">
                            <div class="step-indicator active" data-step="1">
                                <div class="step-circle">1</div>
                                <small>Cita Base</small>
                            </div>
                        </div>
                        <div class="col text-center">
                            <div class="step-indicator" data-step="2">
                                <div class="step-circle">2</div>
                                <small>Servicio</small>
                            </div>
                        </div>
                        <div class="col text-center">
                            <div class="step-indicator" data-step="3">
                                <div class="step-circle">3</div>
                                <small>Ubicación</small>
                            </div>
                        </div>
                        <div class="col text-center">
                            <div class="step-indicator" data-step="4">
                                <div class="step-circle">4</div>
                                <small>Programación</small>
                            </div>
                        </div>
                    </div>

                    <!-- Paso 1: Selección de Cita -->
                    <div class="step-content" id="step1">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-calendar-check"></i> Paso 1: Seleccionar Cita Base
                        </h6>
                        <div class="row">
                            <div class="col-md-8">
                                <label class="form-label">Cita Asociada *</label>
                                <select name="appointment_id" id="appointment_id" class="input-ghost select2" required style="width: 100%;">
                                    <option value="">Buscar y seleccionar cita...</option>
                                    <?php foreach($appointments as $appointment): ?>
                                        <option
                                            value="<?= $appointment->id ?>"
                                            data-date="<?= $appointment->appointment_date ?>"
                                            data-time="<?= $appointment->appointment_time ?>"
                                            data-patient-name="<?= htmlspecialchars($appointment->patient_name, ENT_QUOTES) ?>"
                                        >
                                            Cita #<?= str_pad($appointment->id, 3, '0', STR_PAD_LEFT) ?>
                                            – <?= $appointment->patient_name ?> 
                                            – <?= date('m/d/Y h:i A', strtotime($appointment->appointment_date . ' ' . $appointment->appointment_time)) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">
                                    <i class="fas fa-info-circle"></i> 
                                    Selecciona la cita médica que generará el servicio domiciliario
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <i class="fas fa-calendar-alt fa-2x text-muted mb-2"></i>
                                        <h6>Información de Cita</h6>
                                        <div id="appointmentInfo">
                                            <small class="text-muted">Selecciona una cita para ver detalles</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Paso 2: Información del Servicio -->
                    <div class="step-content d-none" id="step2">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-medical-bag"></i> Paso 2: Información del Servicio
                        </h6>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label">Tipo de Servicio *</label>
                                    <select name="service_type" class="input-ghost" required>
                                        <option value="">Seleccionar tipo...</option>
                                        <option value="Lipid Panel">🩸 Lipid Panel</option>
                                        <option value="Sueros Vitaminados">💧 Sueros Vitaminados</option>
                                        <option value="Chequeo Médico General">🩺 Chequeo Médico General</option>
                                        <option value="Otro">➕ Otro</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Proveedor Asignado</label>
                                    <select name="assigned_provider_id" class="input-ghost select2" style="width: 100%;">
                                        <option value="">Sin asignar (asignar después)</option>
                                        <?php foreach($providers as $provider): ?>
                                            <option value="<?= $provider->id ?>">
                                                👨‍⚕️ <?= $provider->first_name ?> <?= $provider->last_name ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle"></i> 
                                        Puedes asignar el proveedor ahora o después desde la gestión de servicios
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Notas del Servicio</label>
                                    <textarea name="service_notes" class="input-ghost" rows="3" 
                                              placeholder="Instrucciones especiales, equipos necesarios, preparación previa, etc."></textarea>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6><i class="fas fa-lightbulb"></i> Consejos</h6>
                                        <small class="text-muted">
                                            • Especifica equipos médicos necesarios<br>
                                            • Incluye preparación previa del paciente<br>
                                            • Menciona alergias o condiciones especiales<br>
                                            • Indica tiempo estimado del procedimiento
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Paso 3: Ubicación del Servicio -->
                    <div class="step-content d-none" id="step3">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-map-marker-alt"></i> Paso 3: Ubicación del Servicio
                        </h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Estado *</label>
                                    <select name="patient_state" class="input-ghost" required>
                                        <option value="">Seleccionar estado...</option>
                                        <?php foreach($states as $state): ?>
                                            <option value="<?= $state->code ?>"><?= $state->name ?> (<?= $state->code ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Ciudad *</label>
                                    <input type="text" name="patient_city" class="input-ghost" 
                                           placeholder="Ej: San Diego" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Código Postal</label>
                                    <input type="text" name="patient_zipcode" class="input-ghost" 
                                           placeholder="Ej: 92101" maxlength="10">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Dirección Completa *</label>
                                    <textarea name="patient_address" class="input-ghost" rows="4" 
                                              placeholder="Ej: 123 Main Street, Apt 4B&#10;Incluye referencias como edificios cercanos, colores de casa, etc." required></textarea>
                                </div>

                                <div class="alert alert-info">
                                    <i class="fas fa-map"></i>
                                    <strong>Consejo:</strong> Incluye referencias claras como:
                                    <ul class="mb-0 mt-2">
                                        <li>Color de la casa o edificio</li>
                                        <li>Puntos de referencia cercanos</li>
                                        <li>Número de apartamento o piso</li>
                                        <li>Instrucciones de acceso</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Paso 4: Programación -->
                    <div class="step-content d-none" id="step4">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-clock"></i> Paso 4: Programación del Servicio
                        </h6>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Fecha Programada</label>
                                        <input type="date" name="scheduled_date" class="input-ghost" 
                                               value="<?= date('Y-m-d') ?>">
                                        <div class="form-text">Fecha tentativa para realizar el servicio</div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Hora Programada</label>
                                        <input type="time" name="scheduled_time" class="input-ghost" 
                                               value="<?= date('H:i') ?>">
                                        <div class="form-text">Hora aproximada de inicio</div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Prioridad del Servicio</label>
                                    <div class="btn-group w-100" role="group">
                                        <input type="radio" class="btn-check" name="priority" id="priority_normal" value="normal" checked>
                                        <label class="btn btn-outline-success" for="priority_normal">
                                            <i class="fas fa-check-circle"></i> Normal
                                        </label>

                                        <input type="radio" class="btn-check" name="priority" id="priority_urgent" value="urgent">
                                        <label class="btn btn-outline-warning" for="priority_urgent">
                                            <i class="fas fa-exclamation-triangle"></i> Urgente
                                        </label>

                                        <input type="radio" class="btn-check" name="priority" id="priority_emergency" value="emergency">
                                        <label class="btn btn-outline-danger" for="priority_emergency">
                                            <i class="fas fa-ambulance"></i> Emergencia
                                        </label>
                                    </div>
                                </div>

                                <div class="mb-3 d-none">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="requiresEquipment">
                                        <label class="form-check-label" for="requiresEquipment">
                                            <i class="fas fa-medical-bag"></i> Requiere equipo médico especial
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="requiresPreparation">
                                        <label class="form-check-label" for="requiresPreparation">
                                            <i class="fas fa-clock"></i> Requiere preparación previa del paciente
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6><i class="fas fa-calendar-check"></i> Resumen</h6>
                                        <div id="serviceResumen">
                                            <small class="text-muted">Complete los pasos anteriores para ver el resumen</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-ghost btn-ghost-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                    <button type="button" class="btn-ghost btn-ghost-primary" id="prevBtn" onclick="previousStep()" style="display: none;">
                        <i class="fas fa-arrow-left"></i> Anterior
                    </button>
                    <button type="button" class="btn-ghost btn-ghost-primary" id="nextBtn" onclick="nextStep()">
                        Siguiente <i class="fas fa-arrow-right"></i>
                    </button>
                    <button type="submit" class="btn-ghost btn-ghost-success" id="submitBtn" style="display: none;">
                        <i class="fas fa-save"></i> Crear Servicio
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.step-indicator {
    display: inline-block;
    text-align: center;
}

.step-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #e9ecef;
    color: #6c757d;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 8px;
    font-weight: bold;
    transition: all 0.3s ease;
}

.step-indicator.active .step-circle {
    background-color: #28a745;
    color: white;
}

.step-indicator.completed .step-circle {
    background-color: #17a2b8;
    color: white;
}

.step-indicator small {
    color: #6c757d;
    font-weight: 500;
}

.step-indicator.active small {
    color: #28a745;
    font-weight: 600;
}

.select2-container {
    width: 100% !important;
}

.form-check-input:checked + .btn-outline-success {
    background-color: #28a745;
    border-color: #28a745;
    color: white;
}

.form-check-input:checked + .btn-outline-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
}

.form-check-input:checked + .btn-outline-danger {
    background-color: #dc3545;
    border-color: #dc3545;
    color: white;
}
</style>

<script>
let currentStep = 1;
const totalSteps = 4;

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar Select2
    $('#appointment_id').select2({
        placeholder: 'Buscar cita...',
        allowClear: true,
        width: '100%'
    });
    
    $('#assigned_provider_id').select2({
        placeholder: 'Seleccionar proveedor...',
        allowClear: true,
        width: '100%'
    });

    // Event listener para cambio de cita
    $('#appointment_id').on('change', function() {
        const selected = $(this).find(':selected');
        const patient = selected.data('patient-name');
        const date    = selected.data('date');
        const time    = selected.data('time');
        const info    = document.getElementById('appointmentInfo');

        if (selected.val()) {
            info.innerHTML = `
                <div class="text-start">
                    <small><strong>Paciente:</strong><br>${patient}</small><br>
                    <small><strong>Fecha:</strong><br>${new Date(date).toLocaleDateString('es-ES')}</small><br>
                    <small><strong>Hora:</strong><br>${new Date('1970-01-01T' + time)
                        .toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})}</small>
                </div>`;
        } else {
            info.innerHTML = '<small class="text-muted">Selecciona una cita para ver detalles</small>';
        }

        updateResumen();  // si quieres reflejarlo también en el resumen
    });

    // Event listeners para actualizar resumen
    document.querySelectorAll('input, select, textarea').forEach(element => {
        element.addEventListener('change', updateResumen);
    });
});

function nextStep() {
    if (validateCurrentStep()) {
        if (currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
        }
    }
}

function previousStep() {
    if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
    }
}

function showStep(step) {
    // Ocultar todos los pasos
    document.querySelectorAll('.step-content').forEach(content => {
        content.classList.add('d-none');
    });
    
    // Mostrar paso actual
    document.getElementById(`step${step}`).classList.remove('d-none');
    
    // Actualizar indicadores
    document.querySelectorAll('.step-indicator').forEach((indicator, index) => {
        indicator.classList.remove('active', 'completed');
        if (index + 1 < step) {
            indicator.classList.add('completed');
        } else if (index + 1 === step) {
            indicator.classList.add('active');
        }
    });
    
    // Actualizar barra de progreso
    const progress = (step / totalSteps) * 100;
    document.getElementById('progressBar').style.width = `${progress}%`;
    
    // Mostrar/ocultar botones
    document.getElementById('prevBtn').style.display = step > 1 ? 'inline-block' : 'none';
    document.getElementById('nextBtn').style.display = step < totalSteps ? 'inline-block' : 'none';
    document.getElementById('submitBtn').style.display = step === totalSteps ? 'inline-block' : 'none';
    
    updateResumen();
}

function validateCurrentStep() {
    const requiredFields = document.querySelectorAll(`#step${currentStep} [required]`);
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    if (!isValid) {
        alert('Por favor complete todos los campos requeridos antes de continuar.');
    }
    
    return isValid;
}

function updateResumen() {
    if (currentStep < 4) return;
    
    const formData = new FormData(document.getElementById('createServiceForm'));
    const appointmentText = $('#appointment_id option:selected').text();
    const serviceType = formData.get('service_type');
    const providerText = $('#assigned_provider_id option:selected').text();
    const city = formData.get('patient_city');
    const state = formData.get('patient_state');
    const date = formData.get('scheduled_date');
    const time = formData.get('scheduled_time');
    const priority = formData.get('priority');
    
    let resumenHTML = '<div class="text-start small">';
    
    if (appointmentText && appointmentText !== 'Buscar y seleccionar cita...') {
        resumenHTML += `<strong>Cita:</strong><br>${appointmentText}<br><br>`;
    }
    
    if (serviceType) {
        resumenHTML += `<strong>Servicio:</strong><br>${serviceType}<br><br>`;
    }
    
    if (city && state) {
        resumenHTML += `<strong>Ubicación:</strong><br>${city}, ${state}<br><br>`;
    }
    
    if (date && time) {
        const formattedDate = new Date(date).toLocaleDateString('es-ES');
        const formattedTime = new Date('1970-01-01T' + time).toLocaleTimeString('es-ES', {hour: '2-digit', minute:'2-digit'});
        resumenHTML += `<strong>Programado:</strong><br>${formattedDate} ${formattedTime}<br><br>`;
    }
    
    if (providerText && providerText !== 'Seleccionar proveedor...') {
        resumenHTML += `<strong>Proveedor:</strong><br>${providerText}<br><br>`;
    }
    
    if (priority) {
        const priorityTexts = {
            'normal': '🟢 Normal',
            'urgent': '🟡 Urgente', 
            'emergency': '🔴 Emergencia'
        };
        resumenHTML += `<strong>Prioridad:</strong><br>${priorityTexts[priority] || priority}`;
    }
    
    resumenHTML += '</div>';
    
    document.getElementById('serviceResumen').innerHTML = resumenHTML;
}

// Envío del formulario
document.getElementById('createServiceForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    if (!validateCurrentStep()) {
        return;
    }
    
    const formData = new FormData(this);
    const submitBtn = document.getElementById('submitBtn');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creando...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('<?= get_uri("home_services/create_service") ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('modalCreateService')).hide();
            
            // Recargar datos en todas las vistas
            if (typeof loadServices === 'function') loadServices();
            if (typeof loadSchedule === 'function') loadSchedule();
            if (typeof loadMapData === 'function') loadMapData();
            
            // Mostrar mensaje de éxito
            showSuccessMessage(data.message);
            
            // Resetear formulario
            resetForm();
        } else {
            throw new Error(data.message || 'Error al crear el servicio');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error: ' + error.message);
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
});

function resetForm() {
    currentStep = 1;
    document.getElementById('createServiceForm').reset();
    $('#appointment_id').val(null).trigger('change');
    $('#assigned_provider_id').val(null).trigger('change');
    showStep(1);
    document.getElementById('appointmentInfo').innerHTML = '<small class="text-muted">Selecciona una cita para ver detalles</small>';
    document.getElementById('serviceResumen').innerHTML = '<small class="text-muted">Complete los pasos anteriores para ver el resumen</small>';
}

function showSuccessMessage(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed';
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <i class="fas fa-check-circle"></i> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Resetear formulario al abrir modal
document.getElementById('modalCreateService').addEventListener('show.bs.modal', function() {
    resetForm();
});
</script>