<?php

namespace App\Controllers;

use App\Controllers\Security_Controller;
use App\Models\StampTemplate_model;

class StampTemplate extends Security_Controller
{

    protected $stampTemplateModel;

    public function __construct()
    {
        parent::__construct();
        helper('clinics');
        $this->stampTemplateModel = new StampTemplate_model();
    }


    public function index()
    {
        return $this->template->rander('stamptemplate/create');
    }

    public function clinicsAjax()
    {
        $clinics = get_user_clinics($this->login_user->id);
        return $this->response->setJSON(['success' => true, 'clinics' => $clinics]);
    }

    public function create()
    {
        try {

            $json = $this->request->getJSON();
            if (!$json) {
                return $this->response->setJSON(['success' => false, 'message' => 'No se recibieron datos.']);
            }
            $imageData = $json->image;
            if ($imageData) {
                if (preg_match('/^data:image\/(\w+);base64,/', $imageData, $type)) {
                    $imageType = $type[1]; // por ejemplo, png, jpg, etc.
                    $imageData = substr($imageData, strpos($imageData, ',') + 1);
                    $imageData = base64_decode($imageData);
                    if ($imageData === false) {
                        throw new \Exception('Error al decodificar la imagen.');
                    }
                } else {
                    throw new \Exception('Formato de imagen no válido.');
                }

                $uploadPath = WRITEPATH . 'uploads/stamp_templates/';
                if (!is_dir($uploadPath)) {
                    mkdir($uploadPath, 0755, true);
                }
                $fileName = uniqid('stamp_', true) . '.' . $imageType;
                $filePath = $uploadPath . $fileName;
                file_put_contents($filePath, $imageData);

                $storedImage = 'uploads/stamp_templates/' . $fileName;
            } else {
                $storedImage = '';
            }

            $data = [
                'name'                           => $json->name,
                'image'                          => $storedImage, // se guarda la ruta
                'signature_x'                    => $json->coordinates->x,
                'signature_y'                    => $json->coordinates->y,
                'page_size'                      => $json->page_size,
                'clinic_id'                      => ($json->clinic_id === "") ? null : $json->clinic_id,
            ];

            // Agregar datos de orientación si están disponibles
            if (isset($json->orientation_data) && $json->orientation_data) {
                $orientationData = $json->orientation_data;
                $data['is_horizontal'] = $orientationData->isHorizontal ? 1 : 0;
                $data['aspect_ratio'] = $orientationData->aspectRatio;
                $data['rotation'] = $orientationData->rotation;
                $data['orientation'] = $orientationData->orientation;
            }

            $insert_id = $this->stampTemplateModel->ci_save($data);
            if ($insert_id) {
                return $this->response->setJSON(['success' => true, 'message' => 'Plantilla guardada correctamente.']);
            }
            return $this->response->setJSON(['success' => false, 'message' => 'Error al guardar la plantilla.']);
        } catch (\Exception $ex) {
            log_message('error', 'Error en StampTemplate::create - ' . $ex->getMessage());
            return $this->response->setJSON(['success' => false, 'message' => 'Error interno del servidor.' . $ex->getMessage()]);
        }
    }
    /**
     * Retorna la lista de plantillas en formato JSON (para usarse en el modal de selección).
     */
    /*public function listAjax()
    {
        $userClinics = get_user_clinics($this->login_user->id);
        $clinicIds = array_map(fn($c) => $c->id, $userClinics);
        $templates = $this->stampTemplateModel->getAllByClinicsOrGlobal($clinicIds);
        //$templates = $this->stampTemplateModel->get_all()->getResult();
        return $this->response->setJSON(['success' => true, 'templates' => $templates]);
    }*/

    public function listAjax()
    {
        // 1) Traigo las clínicas del usuario
        $userClinics = get_user_clinics($this->login_user->id);
        $clinicIds   = array_map(fn($c) => $c->id, $userClinics);

        // 2) ¿Hay al menos una clínica NO aliada?
        $hasNonAliada = false;
        foreach ($userClinics as $clinic) {
            if (isset($clinic->is_aliada) && intval($clinic->is_aliada) === 0) {
                $hasNonAliada = true;
                break;
            }
        }

        // 3) Obtengo plantillas usando el helper de Crud_model
        if ($hasNonAliada) {
            // → Propias + globales (usa tu método personalizado)
            $templates = $this->stampTemplateModel->getAllByClinicsOrGlobal($clinicIds);
        } else {
            // → Solo propias, SIN globales
            // aquí usamos get_all_where() pasando el where_in:
            $query = $this->stampTemplateModel->get_all_where(
                ['where_in' => ['clinic_id' => $clinicIds]],
                0,      // sin límite
                0,      // sin offset
                'name'  // orden por name ASC
            );
            $templates = $query->getResult();
        }

        return $this->response->setJSON([
            'success'   => true,
            'templates' => $templates
        ]);
    }

    public function updateAjax($id)
    {
        // Leer el JSON enviado por fetch()
        $payload = $this->request->getJSON(true);

        // Mapear sólo los campos que quieres actualizar
        $data = [
            'name'           => $payload['name'],
            'signature_x'    => $payload['signature_x'],
            'signature_y'    => $payload['signature_y'],
        ];

        // Usar ci_save para hacer UPDATE (el segundo parámetro es el ID)
        $this->stampTemplateModel->ci_save($data, (int)$id);

        return $this->response
            ->setStatusCode(200)
            ->setJSON(['success' => true, 'message' => 'Plantilla actualizada']);
    }

    public function getAjax($id)
    {
        $template = $this->stampTemplateModel->get_one_with_clinic($id);
        if (empty($template->id)) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON([
                    'success' => false,
                    'message' => 'Plantilla no encontrada'
                ]);
        }

        // Si la encontramos, devolvemos success + datos
        return $this->response
            ->setStatusCode(200)
            ->setJSON([
                'success'  => true,
                'template' => $template
            ]);
    }

    public function deleteAjax($id)
    {
        // El método delete() de Crud_model marca deleted = 1
        $this->stampTemplateModel->delete((int)$id);

        return $this->response
            ->setStatusCode(200)
            ->setJSON(['success' => true, 'message' => 'Plantilla eliminada']);
    }
}
