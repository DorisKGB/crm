<?php

namespace App\Controllers;

use App\Models\Clinic_model;
use App\Models\Clock_in_model;
use App\Models\Clock_connect_model;
use App\Models\ClinicHours_model;
use App\Models\Team_member_job_info_model;
use Config\Services;
use Exception;


class Clockin extends Security_Controller
{

    protected $ClinicDirectory_model, $ClinicHours_model, $Clock_in_model, $Clock_connect_model, $JobInfo_model;

    public function __construct()
    {
        parent::__construct();
        helper('clinics_helper');
        // Cargamos el modelo del directorio de clínicas
        $this->ClinicDirectory_model = new Clinic_model();
        $this->Clock_in_model    = new Clock_in_model();
        $this->Clock_connect_model    = new Clock_connect_model();
        $this->ClinicHours_model = new ClinicHours_model();
        $this->JobInfo_model = new Team_member_job_info_model();
    }

    // Página principal: carga la vista única del CRUD
    public function index()
    {
        $this->access_user_module('clock_permission','all');

        $request = request(); // Obtener instancia del request
        $clinicId = $request->getGet('clinic');        // equivale a $_GET['clinic']
        $option   = $request->getGet('option') ?? 'attendance'; // valor por defecto
        $user_id   = $request->getGet('user_id'); // valor por defecto
        $date_request   = $request->getGet('date'); // valor por defecto

        $today = date('Y-m-d');
        $from_request = $request->getGet('from') ?? date('Y-m-d', strtotime('-1 month', strtotime($today)));
        $to_request   = $request->getGet('to')   ?? $today;

        if (isset($clinicId)) {
            $data['data_clinic'] = $this->ClinicDirectory_model->get_one($clinicId);
            //$data['users'] = get_clinic_users($clinicId);

             // 1) Clonar el builder para no interferir con otras consultas
            $builder = clone $this->Clock_in_model->db_builder;

            // 2) Hacer la consulta DISTINCT user_id
            $rows = $builder
                ->select('user_id')
                ->distinct()
                ->where('clinic_id', $clinicId)
                ->get()
                ->getResult();  // usa el default 'object'

            // 3) Extraer los IDs en un array simple
            $userIdsWithMarks = array_column($rows, 'user_id');

            // 4) Filtrar tu lista completa de usuarios de la clínica
            $allUsers = get_clinic_users($clinicId);
            $data['users'] = array_filter(
                $allUsers,
                fn($u) => in_array($u->id, $userIdsWithMarks)
            );
        }
        if (isset($user_id)) {
            $data['data_user'] = get_user_by_id($user_id);
        }

        if (isset($option) && $option == "staff"  && isset($clinicId) && isset($user_id)) {
            $connect = $this->Clock_connect_model->get_one_where([
                'clinic_id' => $clinicId,
                'type' => 'connect'
            ]);

            $date = get_today_date();
            if (isset($date_request)) {
                $date = $date_request;
            }

            if (
                $connect &&
                !empty($connect->endpoint) &&
                !empty($connect->api_key) &&
                !empty($connect->api_secret) &&
                !empty($connect->requestid)
            ) {
                $this->syncClockInRecords($clinicId, $user_id, $date);
            }

            $data['request'] = $this->Clock_in_model->get_all_where(['user_id' => $user_id, 'clinic_id' => $clinicId, 'date' => $date])->getResult();
            $data['dataTable'] = $this->getDetalleAsistenciaUsuarioPorFecha($clinicId, $user_id, $date);
        }

        if (isset($option) && $option == "attendance" && isset($clinicId)) {
            $connect = $this->Clock_connect_model->get_one_where([
                'clinic_id' => $clinicId,
                'type' => 'connect'
            ]);
            log_message('debug', "Encontrando data..." . json_encode($connect));
            
            if (
                $connect &&
                !empty($connect->endpoint) &&
                !empty($connect->api_key) &&
                !empty($connect->api_secret) &&
                !empty($connect->requestid)
            ) {
                log_message('debug', "Log: Sincronizando data...");
                $this->syncClockInRecords($clinicId);
            };
            $date = get_today_date();
            if (isset($date_request)) {
                $date = $date_request;
            }
            $data['request'] = $this->Clock_in_model->get_all_where(['clinic_id' => $clinicId, 'date' => $date])->getResult();
        }

        if (isset($option) && $option == "nomina" && isset($clinicId) && isset($user_id)) {
            $connect = $this->Clock_connect_model->get_one_where([
                'clinic_id' => $clinicId,
                'type' => 'connect'
            ]);

            if (
                $connect &&
                !empty($connect->endpoint) &&
                !empty($connect->api_key) &&
                !empty($connect->api_secret) &&
                !empty($connect->requestid)
            ) {
                $this->syncClockInRecords($clinicId);
            };

            $data['nominas'] = $this->nomina_calcular($user_id, $from_request,$to_request);
        }


        $data['clinics'] = get_user_clinics($this->login_user->id);
        return $this->template->rander("clockin/index", $data);
    }

    public function requestToken($clinicId)
    {
        $cache = Services::cache();
        $cacheKey = 'crosschex_token_' . $clinicId;

        // 1. Intenta recuperar token de cache
        /*$cachedToken = $cache->get($cacheKey);
        if ($cachedToken && isset($cachedToken['token']) && isset($cachedToken['expires_at'])) {
            // Verifica si sigue vigente
            if (time() < $cachedToken['expires_at']) {
                return [
                    'token'  => $cachedToken['token'],
                    'cached' => true
                ];
            }
        }*/

        $cached = $cache->get($cacheKey);
        if ($cached && isset($cached['token'], $cached['expires_at'])) {
            // Si expiró, lo borramos para forzar nuevo
            if (time() >= $cached['expires_at']) {
                $cache->delete($cacheKey);
            } else {
                return ['token'=>$cached['token'],'cached'=>true];
            }
        }

        
        // 2. Si no hay token o expiró, solicita uno nuevo
        $connect = $this->Clock_connect_model->get_one_where(['clinic_id' => $clinicId, 'type' => 'connect']);
        $client = Services::curlrequest();

        $url = $connect->endpoint;
        $headers = ['Content-Type' => 'application/json'];

        $body = [
            'header' => [
                'nameSpace'  => 'authorize.token',
                'nameAction' => 'token',
                'version'    => '1.0',
                'requestId'  => $connect->requestid,
                'timestamp'  => gmdate('Y-m-d\TH:i:s\Z')
            ],
            'payload' => [
                'api_key'    => $connect->api_key,
                'api_secret' => $connect->api_secret,
            ]
        ];

        try {
            $response = $client->post($url, [
                'headers' => $headers,
                'json'    => $body
            ]);

            $result = json_decode($response->getBody(), true);
            $token  = $result['payload']['token'] ?? null;
            $expiresRaw = $result['payload']['expires'] ?? null;

            if (!$token || !$expiresRaw) {
                return ['error' => true, 'message' => 'Token o expiración no presentes'];
            }

            // 3. Calcular segundos hasta expiración
            $expiresAt = strtotime($expiresRaw);
            $ttl = $expiresAt - time(); // tiempo en segundos

            if ($ttl > 0) {
                // Guardar en cache
                $cache->save($cacheKey, [
                    'token'       => $token,
                    'expires_at'  => $expiresAt
                ], $ttl);
            }

            return [
                'token'  => $token,
                'cached' => false
            ];
        } catch (\Exception $e) {
            return [
                'error'   => true,
                'message' => $e->getMessage()
            ];
        }
    }

    public function getAttendanceRecords($clinicId, $fecha = null)
    {
        $fecha = $fecha ?? get_today_date();
        $tokenData = $this->requestToken($clinicId);
        log_message('debug', "TokenData: " . json_encode($tokenData));

        if (!isset($tokenData['token'])) {
            return [
                'error'   => true,
                'message' => 'Token no disponible',
                'detail'  => $tokenData
            ];
        }
        $connect = $this->Clock_connect_model->get_one_where(['clinic_id' => $clinicId, 'type' => 'record']);
        log_message('debug', "Connect record: " . json_encode($connect));

        if (!$connect) {
            // No hay configuración de endpoint, devolvemos sin error para no romper la vista
            log_message('error', "No existe configuración record para clínica $clinicId");
            return ['payload' => ['list' => []]];
        }

        $client = Services::curlrequest();
        $url = $connect->endpoint;

        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            log_message('error', "Endpoint inválido para clínica {$clinicId}: {$url}");
            return ['payload' => ['list' => []]];
        }

        $headers = [
            'Content-Type' => 'application/json'
        ];

        // Fechas formateadas
        /*$begin = $fecha . 'T00:00:00+00:00';
        $end   = $fecha . 'T23:59:59+00:00';
        log_message('debug', "Rango local: $begin — $end");*/

        // calcular rango de los últimos 5 días (incluye hoy)
        $fechaFinal  = $fecha;
        $fechaInicio = date('Y-m-d', strtotime("$fechaFinal -4 days"));

        // Fechas en UTC (00:00 inicio, 23:59 fin)
        $begin = $fechaInicio . 'T00:00:00+00:00';
        $end   = $fechaFinal   . 'T23:59:59+00:00';

        log_message('debug', "Rango últimos 5 días: $begin — $end");

        // requestId único
        $requestId = bin2hex(random_bytes(16)); // puedes usar tu lógica personalizada

        $body = [
            'header' => [
                'nameSpace'  => 'attendance.record',
                'nameAction' => 'getrecord',
                'version'    => '1.0',
                'requestId'  => $requestId,
                'timestamp'  => gmdate('Y-m-d\TH:i:s\Z')
            ],
            'authorize' => [
                'type'  => 'token',
                'token' => $tokenData['token']
            ],
            'payload' => [
                'begin_time' => $begin,
                'end_time'   => $end,
                'order'      => 'asc',
                'page'       => '1',
                'per_page'   => '100'
            ]
        ];

        try {
            $response = $client->post($url, [
                'headers' => $headers,
                'json'    => $body,
                'timeout'     => 10,
                'http_errors' => false,
            ]);
            log_message('debug', "HTTP {$response->getStatusCode()} — Body: " . $response->getBody());
            $decoded = json_decode($response->getBody(), true);
            log_message('debug', "Decoded payload: " . json_encode($decoded['payload']['list'] ?? []));

            return json_decode($response->getBody(), true);
        } catch (\Exception $e) {
            log_message('error', "Excepción cURL: " . $e->getMessage());
            return [
                'error'   => true,
                'message' => $e->getMessage()
            ];
        }
    }

    
    public function syncClockInRecords($clinicId, $userId = null, $fecha = null)
    {
        $fecha = $fecha ?? get_today_date();
        $records = $this->getAttendanceRecords($clinicId, $fecha);

        if (!isset($records['payload']['list']) || !is_array($records['payload']['list'])) {
            /*return $this->response->setJSON([
                'success' => false,
                'message' => 'No se encontraron registros o hubo un error',
                'data' => $records
            ]);*/
            log_message('error', 'syncClockInRecords: no payload for clinic ' . $clinicId);
            return false;
        }

        $insertados = 0;

        foreach ($records['payload']['list'] as $entry) {
            $workno = $entry['employee']['workno'] ?? null;

            if ($userId != null) {
                // Filtra solo si el workno coincide con el user_id dado
                if ((string)$workno !== (string)$userId) {
                    continue;
                }
            }
            $clinicOne = $this->ClinicDirectory_model->get_one($clinicId);
            $checktime = $entry['checktime'];
            log_message('error', "Asi me llega el datetime: ".$entry['checktime']);
            $localDateTime = convert_date($checktime,"Y-m-d H:i:s",$clinicOne->schedule);
            $date = get_date_from_datetime($localDateTime);
            $time = get_time_from_datetime($localDateTime);


            // Verifica si ya existe en la tabla
            $existe = $this->Clock_in_model->get_one_where([
                'user_id'   => ($userId === null) ? $workno : $userId ,
                'clinic_id' => $clinicId,
                'date'      => $date,
                'time'      => $time,
                'deleted'   => 0
            ]);

            if (empty($existe->id)) {
                $data = [
                    'user_id'   => ($userId === null) ? $workno : $userId,
                    'clinic_id' => $clinicId,
                    'date'      => $date,
                    'time'      => $time,
                    'remark'    => 'Importado desde CrossChex'
                ];
                $this->Clock_in_model->ci_save($data);
            }

            /*if (!empty($existe->id)) {
                continue;
            }
            
            $data = [
                'user_id'   => ($userId === null) ? $workno : $userId,
                'clinic_id' => $clinicId,
                'date'      => $date,
                'time'      => $time,
                'remark'    => 'Importado desde CrossChex'
            ];
            // Insertar nuevo registro
            $this->Clock_in_model->ci_save($data);*/

            //ATTENDANCE
            $datetime = date(
                'Y-m-d H:i:s',
                strtotime("{$date} {$time}")
            );

            $existsClockIn = $this->Attendance_model
                ->findApprovedByUserOnDate(($userId === null) ? $workno : $userId, $date);


            $CantidadMarcajes = $this->Clock_in_model->where('user_id', ($userId === null) ? $workno : $userId)
                ->where('clinic_id', $clinicId)
                ->where('date',      $date)
                ->countAllResults();

            if (isset($existsClockIn->id)) {
                if ($CantidadMarcajes === 1) {
                    $dataNew = [
                        'in_time' => $datetime,
                    ];
                    $this->Attendance_model->ci_save($dataNew, $existsClockIn->id);
                } else if ($CantidadMarcajes > 1) {
                    $dataNew = [
                        'status' => 'pending',
                        'out_time'      => $datetime,
                        'note'    => 'Salida'
                    ];
                    $this->Attendance_model->ci_save($dataNew, $existsClockIn->id);
                }
            } else {
                $dataNew = [
                    'status' => 'incomplete',
                    'user_id'   => ($userId === null) ? $workno : $userId,
                    'in_time'      => $datetime,
                ];
                $this->Attendance_model->ci_save($dataNew);
            }

            $insertados++;
        }
        return true;
        //return json_decode($insertados, true);
        /*return $this->response->setJSON([
            'success'    => true,
            'insertados' => $insertados
        ]);*/
    }

    public function ajaxSyncLastDays()
{
    $request  = service('request');
    $clinicId = $request->getGet('clinic');
    $days     = (int) ($request->getGet('days') ?? 15);

    if (! $clinicId) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Falta el parámetro clinic'
        ]);
    }

    $today = date('Y-m-d');

    // Iteramos los últimos $days días
    for ($i = 0; $i < $days; $i++) {
        $date = date('Y-m-d', strtotime("-{$i} days", strtotime($today)));

        try {
            $ok = $this->syncClockInRecords($clinicId, null, $date);

            if (! $ok) {
                // No hubo registros ese día (no es un error fatal)
                log_message('warning', "ajaxSyncLastDays: sin registros para $date");
            }
        } catch (\Throwable $e) {
            // Si cualquier día lanza excepción, la capturamos y seguimos con el siguiente
            log_message('error', "ajaxSyncLastDays: error sincronizando $date -> ".$e->getMessage());
        }
    }

    return $this->response->setJSON([
        'success' => true,
        'message' => "Sincronizados últimos {$days} días"
    ]);
}

    public function getHorasPorDia()
    {
        $request = service('request');
        $userId = $request->getGet('user_id');
        $clinicId = $request->getGet('clinic_id');
        $from = $request->getGet('from');
        $to = $request->getGet('to');

        if (!$userId || !$clinicId || !$from || !$to) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Faltan parámetros.'
            ]);
        }

        $fromDate = new \DateTime($from);
        $toDate = new \DateTime($to);
        $interval = new \DateInterval('P1D');
        $dateRange = new \DatePeriod($fromDate, $interval, $toDate->modify('+1 day'));

        $result = [];

        foreach ($dateRange as $date) {
            $day = $date->format('Y-m-d');

            $registros = $this->Clock_in_model->get_all_where([
                'user_id' => $userId,
                'clinic_id' => $clinicId,
                'date' => $day
            ])->getResult();

            $segundos = 0;
            $accion = 'Entrada';
            $ultimaEntrada = null;

            foreach ($registros as $registro) {
                $hora = \DateTime::createFromFormat('H:i:s', $registro->time);
                if ($accion === 'Entrada') {
                    $ultimaEntrada = $hora;
                    $accion = 'Salida';
                } else {
                    if ($ultimaEntrada) {
                        $diff = $hora->getTimestamp() - $ultimaEntrada->getTimestamp();
                        $segundos += $diff;
                    }
                    $accion = 'Entrada';
                }
            }

            $horas = round($segundos / 3600, 2);
            $result[] = [
                'fecha' => $day,
                'horas' => $horas
            ];
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }

    public function getResumenAsistenciaPorClinica()
    {
        $request  = service('request');
        $clinicId = $request->getGet('clinic_id');
        $from     = $request->getGet('from');
        $to       = $request->getGet('to');

        if (! $clinicId || ! $from || ! $to) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Parámetros incompletos.'
            ]);
        }

        // 1) Obtener sólo los user_id que tienen al menos un registro en la clínica
        $builder = clone $this->Clock_in_model->db_builder;
        $rows = $builder
            ->select('user_id')
            ->distinct()
            ->where('clinic_id', $clinicId)
            ->get()
            ->getResult();  // devuelve array de objetos

        $userIdsWithMarks = array_column($rows, 'user_id');

        // 2) Filtrar la lista completa de usuarios de la clínica
        $allUsers = get_clinic_users($clinicId);
        $usuarios = array_filter(
            $allUsers,
            fn($u) => in_array($u->id, $userIdsWithMarks)
        );

        // 3) Preparar el rango de fechas
        $fromDate  = new \DateTime($from);
        $toDate    = new \DateTime($to);
        $interval  = new \DateInterval('P1D');
        $dateRange = new \DatePeriod($fromDate, $interval, $toDate->modify('+1 day'));

        $datos = [];

        // 4) Calcular horas para cada usuario filtrado
        foreach ($usuarios as $user) {
            $horasTotales = 0;

            foreach ($dateRange as $date) {
                $fecha    = $date->format('Y-m-d');
                $registros = $this->Clock_in_model
                    ->get_all_where([
                        'user_id'   => $user->id,
                        'clinic_id' => $clinicId,
                        'date'      => $fecha
                    ])
                    ->getResult();

                $segundos      = 0;
                $accion        = 'Entrada';
                $ultimaEntrada = null;

                foreach ($registros as $registro) {
                    $hora = \DateTime::createFromFormat('H:i:s', $registro->time);
                    if ($accion === 'Entrada') {
                        $ultimaEntrada = $hora;
                        $accion = 'Salida';
                    } else {
                        if ($ultimaEntrada) {
                            $segundos += $hora->getTimestamp() - $ultimaEntrada->getTimestamp();
                        }
                        $accion = 'Entrada';
                    }
                }

                $horasTotales += round($segundos / 3600, 2);
            }

            $datos[] = [
                'nombre' => $user->first_name . ' ' . $user->last_name,
                'rol'    => $user->job_title,
                'horas'  => round($horasTotales, 2),
                'foto'   => $user->image
            ];
        }

        return $this->response->setJSON([
            'success' => true,
            'data'    => $datos
        ]);
    }



    public function getDetalleAsistenciaUsuarioPorFecha($clinicId, $userId, $fecha)
    {
        $detalle = [];

        $date = new \DateTime($fecha);
        $diaSemana = (int)$date->format('w');

        $horario = $this->ClinicHours_model->get_one_where([
            'clinic_id' => $clinicId,
            'day_of_week' => $diaSemana
        ]);

        if (!$horario) return [];

        $opening = $horario->opening_time;
        $closing = $horario->closing_time;

        $registros = $this->Clock_in_model->get_all_where([
            'user_id' => $userId,
            'clinic_id' => $clinicId,
            'date' => $fecha
        ])->getResult();

        if (count($registros) === 0) return [];

        $horas = array_map(fn($r) => $r->time, $registros);
        sort($horas);

        $entradaReal = $horas[0];
        $entradaDiff = strtotime($entradaReal) - strtotime($opening);

        // Mostrar salida solo si número de registros es par
        $salidaReal = (count($horas) % 2 === 0) ? $horas[count($horas) - 1] : '--';

        // Calcular desfase salida solo si hay al menos 2 registros
        if (count($horas) >= 2 && $salidaReal !== '--') {
            $salidaDiff = strtotime($salidaReal) - strtotime($closing);
            $outOffset = $this->formatearDesfase($salidaDiff);
            $outColor = $salidaDiff > 0 ? '#f8d7da' : '#d4edda';
        } else {
            $outOffset = '--';
            $outColor = '#eeeeee';
        }


        $detalle[] = [
            'date' => $fecha,
            'check_in' => $entradaReal,
            'check_out' => $salidaReal,
            'late' => $entradaDiff > 0
                ? '<button class="rounded-circle" style="background-color: #f8d7da; color: #721c24; width: 40px; height: 40px; border: none;"><i class="fas fa-times"></i></button><span class="ms-2 text-danger fw-bold">Llegó Tarde</span>'
                : '<button class="rounded-circle" style="background-color: #d4edda; color: #155724; width: 40px; height: 40px; border: none;"><i class="fas fa-check"></i></button><span class="ms-2 text-success fw-bold">Puntual</span>',
            'in_offset' => $this->formatearDesfase($entradaDiff),
            'out_offset' => $outOffset,
            'in_color' => $entradaDiff > 0 ? '#f8d7da' : '#d4edda',
            'out_color' => $outColor
        ];

        return $detalle;
    }


    private function formatearDesfase($segundos)
    {
        $minutos = round(abs($segundos) / 60);
        if ($segundos === 0) return '0 min';
        return ($segundos > 0 ? "+$minutos min" : "-$minutos min");
    }

    public function nomina_calcular($userId, $from, $to)
    {
        if (!$userId || !$from || !$to) {
            return $this->response->setJSON(['success' => false, 'message' => 'Faltan datos.']);
        }

        $registros = $this->Clock_in_model->get_by_range($userId, $from, $to);
        $horas = 0;
        $accion = 'Entrada';
        $last = null;

        foreach ($registros as $r) {
            $time = \DateTime::createFromFormat('H:i:s', $r->time);
            if ($accion === 'Entrada') {
                $last = $time;
                $accion = 'Salida';
            } else {
                if ($last) {
                    $diff = $time->getTimestamp() - $last->getTimestamp();
                    $horas += $diff;
                    $last = null;
                }
                $accion = 'Entrada';
            }
        }

        $horasTrabajadas = round($horas / 3600, 2);
        $job = $this->JobInfo_model->get_one_where(['user_id' => $userId]);
        $salario = $job ? $job->salary : 0;
        $salarioHora = $salario; //

        return [
            'success' => true,
            'total_horas' => $horasTrabajadas,
            'salario_hora' => $salarioHora,
            'total' => $horasTrabajadas * $salarioHora
        ];
    }
}