<div id="page-content" class="page-wrapper clearfix">

    <div class="view-container">
        <?php echo nl2br($model_info->content ? $model_info->content : ""); ?>
    </div>

</div>